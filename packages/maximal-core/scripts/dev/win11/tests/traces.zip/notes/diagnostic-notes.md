# winvm diagnostic notes

Break-glass reference for a Windows guest that will not build, boot, or behave.
Deliberately kept inside `traces.zip` rather than loose in the tree: these are
descriptions of BROKEN configurations, and they should not be found by anything
browsing the working code.

Run `winvm diagnose [-i name]` first. It encodes most of what follows.

---

## The thing that makes this hard

**Every failure looks identical from outside.** In all of them the QEMU process
is alive, the pidfile is valid, and the monitor answers `VM status: running`.
Liveness tells you nothing here. Only artifacts distinguish the cases, and the
artifact that matters differs per failure.

---

## FALSE SIGNATURES — read this before concluding anything

These look like faults and are not. Each one cost real time, and two of them
nearly ended up encoded as "failures" in the diagnostic itself.

**`BdsDxe: starting Boot0001 "UEFI Misc Device"` followed by silence is a
HEALTHY boot.** On virtio-blk the firmware labels the boot disk "UEFI Misc
Device", starts it, and stops writing to the serial console because the OS
loader has taken over. A healthy instance's `serial.log` and a hung one can be
the same length. Do not treat "console went quiet" as a hang on its own —
`Windows Boot Manager` only appeared in older logs because the disk was NVMe.

**The guest agent answering does NOT mean the guest is ready.** `qemu-ga` runs
as SYSTEM and answers `guest-ping` — and serves `guest-exec` — throughout the
out-of-box experience, while the screen still reads "Just a moment, checking for
updates". During that window Windows also reports `OOBEInProgress = 0`,
`SystemSetupInProgress = 0`, and a running `explorer.exe`. There is no probe
that returns "not yet". The only honest readiness signal is
`Win32_ComputerSystem.UserName` no longer being `defaultuser0`; with audit mode
configured it should be `<HOST>\Administrator`.

**QEMU reports a failed launch on stderr and then exits 0.** A bad command line
or an unreachable socket produces no non-zero status. If `qemu.log` has content,
the guest never started, and every other artifact is from a machine that was
never running.

**Low CPU with no disk writes is often normal.** "Your PC will restart in a few
moments" idles at single-digit CPU with a flat overlay for a minute or more.

---

## Failure modes

### Install freezes at a percentage, no error
Screen shows "Are you sure you want to quit?" over the Setup progress page.
Caused by surplus keystrokes: the host used to press Enter every 400ms until the
disk grew past 300MB — about 250 presses for a prompt that consumes one. The
extras queue in the keyboard buffer and are delivered to Setup's GUI, where
Enter activates the focused Cancel. Stopping earlier cannot help; the keys are
already queued. Fixed by a handshake — `startup.nsh` prints
`winvm-keypress-needed` and the host sends five keystrokes, bounded.

### Firmware spins, console frozen, no boot target
`serial.log` stops dead on `UsbBootExecCmd: Success to Exec 0x0 Cmd (Result = 1)`
with a core at 100% and the file never growing again. EDK2's USB mass-storage
command layer. Intermittent — roughly one boot in three when it was present.
Seen on both `nec-usb-xhci` and `qemu-xhci`, and on an instance carrying only one
USB disk, so it is not about how many devices are attached. Fixed by attaching no
USB storage to a running instance at all. The firmware is prebuilt
(`edk2-stable202408-prebuilt.qemu.org`) and cannot be patched, only avoided.

### Guest reaches a desktop but has no agent, and nothing says why
Provisioning never ran. Almost always the answer file requesting audit mode
while leaving OOBE logon settings in place: Windows honours both halves, so
`audit.exe` enables the built-in Administrator and arranges to be re-called as
`audit.exe /user` on the audit logon — and then `AutoLogon` signs in the answer
file's own account instead. The audit logon never happens, the `auditUser` pass
never runs, provisioning never runs. Confirm by reading, inside the guest disk,
`C:\Windows\Panther\UnattendGC\Setupact.log`; look for `audit.exe` lines and
compare against which accounts exist under `C:\Users`. The `oobeSystem` pass must
contain nothing but `Reseal`.

### Build reports success but the image is empty or broken
"QEMU exited" used to be the only completion signal, so a crash, a kill, or a
launch that never happened all sealed whatever the disk held into a read-only
base image. A silent launch failure sealed an empty 64 GB disk in 15 seconds and
`build` then refused to replace it. Builds now gate on the guest's own
`winvm-provisioned.txt` marker.

### Build fails right at the end with a guest agent timeout
Provisioning installs `vioserial`, the driver underneath the channel the agent
speaks over, so the agent drops and returns mid-run. Polling must tolerate it.

### Snapshot livelocks the guest
All vCPUs at 100%, no disk I/O, no recovery but `kill`. Caused by snapshotting a
guest that had not finished starting. Take snapshots only against a settled
desktop; `winvm snapshot` refuses otherwise.

### savevm refuses, naming a device
Every writable device must support snapshots. Three had to change: the NVMe boot
disk (non-migratable — hence virtio-blk), raw pflash firmware variables (now
qcow2), and the writable raw result volume (now attached only while building).

### Rewind appears to change nothing
`loadvm` returns before the guest can serve a command. A fixed sleep that is
slightly too short gets a reply from across the restore, which makes a working
rewind look like a no-op. Wait for the agent, do not sleep.

---

## Sources

- Audit mode, and `Reseal | Mode = Audit`:
  <https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/boot-windows-to-audit-mode-or-oobe>
- `Reseal | Mode` values and the pass/mode table:
  <https://learn.microsoft.com/en-us/windows-hardware/customize/desktop/unattend/microsoft-windows-deployment-reseal-mode>
- `SetupComplete.cmd`, the `auditUser` pass, and the warning against shutting
  down from a Setup script:
  <https://learn.microsoft.com/en-us/windows-hardware/manufacture/desktop/add-a-custom-script-to-windows-setup>
- A working Windows ARM64 QEMU command line (note: TCG, not HVF):
  <https://linaro.atlassian.net/wiki/spaces/WOAR/pages/28914909194/windows-arm64+VM+using+qemu-system>
- QEMU USB controller guidance:
  <https://qemu-project.gitlab.io/qemu/system/devices/usb.html>
- `nec-usb-xhci` open bug:
  <https://gitlab.com/qemu-project/qemu/-/issues/3241>
