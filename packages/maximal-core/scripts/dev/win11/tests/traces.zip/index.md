# winvm traces

Recorded artifacts of Windows guests that failed — and of guests that did not,
which matters just as much. `scripts/dev/win11/tests/diagnose.test.ts` runs
`winvm diagnose` against every one of them.

**Why this is a zip.** These are frozen pictures of BROKEN configurations. Loose
in the repository they are a trap: anyone — or any agent — reading the tree to
learn how this harness works would find a folder full of things that do not
work, sitting next to the code that does. Archived, they stay retrievable for
someone actually diagnosing a fault and invisible the rest of the time.

## Contents

| Path | What |
|---|---|
| `index.md` | this file |
| `notes/diagnostic-notes.md` | the write-up: failure modes, false signatures, sources |
| `traces/ok-*` | guests that were HEALTHY — the controls |
| `traces/fail-*` | guests that failed, one directory per mode |

Each trace directory holds:

- `WHAT-THIS-IS.txt` — one paragraph, including whether it was captured or reconstructed
- `expected.json` — the instance to diagnose and the findings expected, so the
  test carries no knowledge of its own
- `state/` — a complete `WINVM_HOME`: `instances/<name>/…` and `images/<name>/…`
- `answer/autounattend.xml` — only where the trace is about the answer file

## Fidelity

Serial logs, `qemu.log` and answer files are the real thing unless
`WHAT-THIS-IS.txt` says otherwise; one trace is explicitly reconstructed and says
so. `*.qcow2` files are **placeholders** — `diagnose` only ever stats them, never
opens them, so shipping real disk images would add gigabytes for nothing.
`qemu.pid` is deliberately absent: a recorded PID could collide with a live
process on the machine running the test and change the result.

## The pair worth understanding

`fail-firmware-usb-stopped` and `ok-build-past-usb-transient` are the same moment
in a build, 4180 bytes of console apart. A guest passes *through* that state
normally; it is a failure only when nothing follows. This is why the check is
qualified by whether progress has stopped, and why "the console went quiet" is
never on its own a diagnosis. The notes list the other false signatures.
